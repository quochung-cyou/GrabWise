// config.ts
export const MAPBOX_TOKEN = "pk.eyJ1IjoicXVvY2h1bmdjeW91IiwiYSI6ImNtM3JndzVkbDA2bWoybHNiOG5tamtzb2kifQ.wy1FntGhMO093jvC5RyoaA";
export const VITE_OPENWEATHER_API_KEY = "f6531adea60f0d386c77dce30be52c5e";